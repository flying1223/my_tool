If you are running into a bug, please read https://packagecontrol.io/docs/troubleshooting
before submitting an issue here.

Bug reports must include a debug log. The Troubleshooting page explains how to capture one.

